public class Self {
    public static void main(String[] args) {
        String fullName = "Brandon Kim";
        int age = 27;
        String homeTown = "Long Beach, CA";
        System.out.println("My name is: " + fullName);
        System.out.printf("I am %s years old \n", age);
        System.out.println("My hometown is " + homeTown);
    }
}
